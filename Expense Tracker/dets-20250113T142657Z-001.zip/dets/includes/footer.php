<div class="col-sm-12 " style="margin-top: 15px;">
				<p class="back-link" style="margin-left: 250px;">Daily Expense Tracker by Prajjwal Tiwari </p>
			</div>